namespace JPEGVIEW
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.file1 = new System.Windows.Forms.ToolStripMenuItem();
            this.open1 = new System.Windows.Forms.ToolStripMenuItem();
            this.close1 = new System.Windows.Forms.ToolStripMenuItem();
            this.closeAll1 = new System.Windows.Forms.ToolStripMenuItem();
            this.stretch1 = new System.Windows.Forms.ToolStripMenuItem();
            this.resize1 = new System.Windows.Forms.ToolStripMenuItem();
            this.resizeAll1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.exit1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.file1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(292, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Visible = false;
            // 
            // file1
            // 
            this.file1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.open1,
            this.close1,
            this.closeAll1,
            this.stretch1,
            this.resize1,
            this.resizeAll1,
            this.toolStripMenuItem1,
            this.exit1});
            this.file1.MergeAction = System.Windows.Forms.MergeAction.Replace;
            this.file1.Name = "file1";
            this.file1.Size = new System.Drawing.Size(35, 20);
            this.file1.Text = "&File";
            // 
            // open1
            // 
            this.open1.Name = "open1";
            this.open1.Size = new System.Drawing.Size(152, 22);
            this.open1.Text = "&Open";
            this.open1.Click += new System.EventHandler(this.open1_Click);
            // 
            // close1
            // 
            this.close1.Name = "close1";
            this.close1.Size = new System.Drawing.Size(152, 22);
            this.close1.Text = "&Close";
            this.close1.Click += new System.EventHandler(this.close1_Click);
            // 
            // closeAll1
            // 
            this.closeAll1.Name = "closeAll1";
            this.closeAll1.Size = new System.Drawing.Size(152, 22);
            this.closeAll1.Text = "Close &All";
            this.closeAll1.Click += new System.EventHandler(this.closeAll1_Click);
            // 
            // stretch1
            // 
            this.stretch1.CheckOnClick = true;
            this.stretch1.Name = "stretch1";
            this.stretch1.Size = new System.Drawing.Size(152, 22);
            this.stretch1.Text = "&Stretch";
            this.stretch1.CheckedChanged += new System.EventHandler(this.stretch1_CheckedChanged);
            // 
            // resize1
            // 
            this.resize1.Name = "resize1";
            this.resize1.Size = new System.Drawing.Size(152, 22);
            this.resize1.Text = "&Resize";
            this.resize1.Click += new System.EventHandler(this.resize1_Click);
            // 
            // resizeAll1
            // 
            this.resizeAll1.Name = "resizeAll1";
            this.resizeAll1.Size = new System.Drawing.Size(152, 22);
            this.resizeAll1.Text = "R&esize All";
            this.resizeAll1.Click += new System.EventHandler(this.resizeAll1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(149, 6);
            // 
            // exit1
            // 
            this.exit1.Name = "exit1";
            this.exit1.Size = new System.Drawing.Size(152, 22);
            this.exit1.Text = "E&xit";
            this.exit1.Click += new System.EventHandler(this.exit1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(-2, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.ShowInTaskbar = false;
            this.Text = "Form2";
            this.Enter += new System.EventHandler(this.Form2_Enter);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form2_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem file1;
        private System.Windows.Forms.ToolStripMenuItem open1;
        private System.Windows.Forms.ToolStripMenuItem close1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exit1;
        internal System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem closeAll1;
        private System.Windows.Forms.ToolStripMenuItem resize1;
        private System.Windows.Forms.ToolStripMenuItem resizeAll1;
        internal System.Windows.Forms.ToolStripMenuItem stretch1;
    }
}