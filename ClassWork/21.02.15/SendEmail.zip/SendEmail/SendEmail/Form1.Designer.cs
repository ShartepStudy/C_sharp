﻿namespace SendEmail
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.SenderName_TB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.RecipientEmail_TB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.MailText_TB = new System.Windows.Forms.TextBox();
            this.Send_Button = new System.Windows.Forms.Button();
            this.Subject_TB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Login = new System.Windows.Forms.TextBox();
            this.Parol = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Sign1 = new System.Windows.Forms.Button();
            this.Service_CB = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SenderName_TB
            // 
            this.SenderName_TB.Location = new System.Drawing.Point(126, 66);
            this.SenderName_TB.Name = "SenderName_TB";
            this.SenderName_TB.Size = new System.Drawing.Size(200, 20);
            this.SenderName_TB.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Имя Отправителя:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Кому Отправить:";
            // 
            // RecipientEmail_TB
            // 
            this.RecipientEmail_TB.Location = new System.Drawing.Point(126, 101);
            this.RecipientEmail_TB.Name = "RecipientEmail_TB";
            this.RecipientEmail_TB.Size = new System.Drawing.Size(200, 20);
            this.RecipientEmail_TB.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Текст Сообщения:";
            // 
            // MailText_TB
            // 
            this.MailText_TB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MailText_TB.Location = new System.Drawing.Point(12, 176);
            this.MailText_TB.Multiline = true;
            this.MailText_TB.Name = "MailText_TB";
            this.MailText_TB.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.MailText_TB.Size = new System.Drawing.Size(801, 240);
            this.MailText_TB.TabIndex = 10;
            // 
            // Send_Button
            // 
            this.Send_Button.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Send_Button.Location = new System.Drawing.Point(12, 422);
            this.Send_Button.Name = "Send_Button";
            this.Send_Button.Size = new System.Drawing.Size(90, 26);
            this.Send_Button.TabIndex = 11;
            this.Send_Button.Text = "Отправить!";
            this.Send_Button.UseVisualStyleBackColor = true;
            this.Send_Button.Click += new System.EventHandler(this.Send_Button_Click);
            // 
            // Subject_TB
            // 
            this.Subject_TB.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Subject_TB.Location = new System.Drawing.Point(55, 130);
            this.Subject_TB.Name = "Subject_TB";
            this.Subject_TB.Size = new System.Drawing.Size(687, 20);
            this.Subject_TB.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Тема:";
            // 
            // Login
            // 
            this.Login.Location = new System.Drawing.Point(299, 150);
            this.Login.Name = "Login";
            this.Login.Size = new System.Drawing.Size(222, 20);
            this.Login.TabIndex = 17;
            // 
            // Parol
            // 
            this.Parol.Location = new System.Drawing.Point(299, 200);
            this.Parol.Name = "Parol";
            this.Parol.Size = new System.Drawing.Size(222, 20);
            this.Parol.TabIndex = 18;
            this.Parol.UseSystemPasswordChar = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(395, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Логин";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(388, 184);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Пароль";
            // 
            // Sign1
            // 
            this.Sign1.Location = new System.Drawing.Point(299, 242);
            this.Sign1.Name = "Sign1";
            this.Sign1.Size = new System.Drawing.Size(222, 46);
            this.Sign1.TabIndex = 21;
            this.Sign1.Text = "Sign ";
            this.Sign1.UseVisualStyleBackColor = true;
            this.Sign1.Click += new System.EventHandler(this.Sign1_Click);
            // 
            // Service_CB
            // 
            this.Service_CB.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Service_CB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Service_CB.FormattingEnabled = true;
            this.Service_CB.Items.AddRange(new object[] {
            "@gmail.com",
            "@mail.ru",
            "@yandex.ru",
            "@ukr.net"});
            this.Service_CB.Location = new System.Drawing.Point(540, 149);
            this.Service_CB.Name = "Service_CB";
            this.Service_CB.Size = new System.Drawing.Size(110, 21);
            this.Service_CB.TabIndex = 22;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.pictureBox1.BackgroundImage = global::SendEmail.Properties.Resources.Goomba;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(12, 73);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(236, 310);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(825, 460);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Service_CB);
            this.Controls.Add(this.Sign1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Parol);
            this.Controls.Add(this.Login);
            this.Controls.Add(this.Subject_TB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Send_Button);
            this.Controls.Add(this.MailText_TB);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.RecipientEmail_TB);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SenderName_TB);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Send Email";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox SenderName_TB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox RecipientEmail_TB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox MailText_TB;
        private System.Windows.Forms.Button Send_Button;
        private System.Windows.Forms.TextBox Subject_TB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Login;
        private System.Windows.Forms.TextBox Parol;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button Sign1;
        private System.Windows.Forms.ComboBox Service_CB;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

