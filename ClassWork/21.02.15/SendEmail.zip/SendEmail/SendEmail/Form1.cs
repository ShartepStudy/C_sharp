﻿using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace SendEmail
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Service_CB.SelectedIndex = 0;
            POMENYAT(false);

        }
        private void POMENYAT(bool a)
        {

            
            SenderName_TB.Visible = a;
            MailText_TB.Visible = a;
            Subject_TB.Visible = a;
           
            RecipientEmail_TB.Visible = a;
            Send_Button.Visible = a;
            label1.Visible = a;
           
            label4.Visible = a;
            label5.Visible = a;
            label6.Visible = a;
           
        }
        private void Send_Button_Click(object sender, EventArgs e)
        {
            try
            {

                if (Service_CB.SelectedIndex == 0)
                {
                    //Gmail

                    using (MailMessage mm = new MailMessage(SenderName_TB.Text + "<" + Login.Text + ">", RecipientEmail_TB.Text))
                    {
                        mm.Subject = Subject_TB.Text;
                        mm.Body = MailText_TB.Text;
                        using (SmtpClient sc = new SmtpClient("smtp.gmail.com", 587))
                        {
                            sc.EnableSsl = true;
                            sc.DeliveryMethod = SmtpDeliveryMethod.Network;
                            sc.UseDefaultCredentials = false;
                            sc.Timeout = 30000;
                            sc.Credentials = new NetworkCredential(Login.Text, Parol.Text);
                            sc.Send(mm);
                        }
                    }
                }

                else if (Service_CB.SelectedIndex == 1)
                {
                    //Yandex

                    using (MailMessage mm = new MailMessage(SenderName_TB.Text + "<" + Login.Text + ">", RecipientEmail_TB.Text))
                    {
                        mm.Subject = Subject_TB.Text;
                        mm.Body = MailText_TB.Text;
                        using (SmtpClient sc = new SmtpClient("smtp.yandex.ru", 25))
                        {
                            sc.EnableSsl = true;
                            sc.DeliveryMethod = SmtpDeliveryMethod.Network;
                            sc.UseDefaultCredentials = false;
                            sc.Timeout = 30000;
                            sc.Credentials = new NetworkCredential(Login.Text, Parol.Text);
                            sc.Send(mm);
                        }
                    }

                }

                else if (Service_CB.SelectedIndex == 2)
                {
                    //Mail.ru

                    using (MailMessage mm = new MailMessage(SenderName_TB.Text + "<" + Login.Text + ">", RecipientEmail_TB.Text))
                    {
                        mm.Subject = Subject_TB.Text;
                        mm.Body = MailText_TB.Text;
                        using (SmtpClient sc = new SmtpClient("smtp.mail.ru", 25))
                        {
                            sc.EnableSsl = true;
                            sc.DeliveryMethod = SmtpDeliveryMethod.Network;
                            sc.UseDefaultCredentials = false;
                            sc.Timeout = 30000;
                            sc.Credentials = new NetworkCredential(Login.Text, Parol.Text);
                            sc.Send(mm);
                        }
                    }
                }
                if (Service_CB.SelectedIndex == 4)
                {
                    //Gmail

                    using (MailMessage mm = new MailMessage(SenderName_TB.Text + "<" + Login.Text + ">", RecipientEmail_TB.Text))
                    {
                        mm.Subject = Subject_TB.Text;
                        mm.Body = MailText_TB.Text;
                        using (SmtpClient sc = new SmtpClient("smtp.ukr.net", 2525))
                        {
                            sc.EnableSsl = true;
                            sc.DeliveryMethod = SmtpDeliveryMethod.Network;
                            sc.UseDefaultCredentials = false;
                            sc.Timeout = 30000;
                            sc.Credentials = new NetworkCredential(Login.Text, Parol.Text);
                            sc.Send(mm);
                        }
                    }
                }
                System.Threading.Thread.Sleep(1000);
                POMENYAT(false);

                MessageBox.Show("Ваше сообщение отправлено!");
            }
            catch
            {
                MessageBox.Show("Не все поля заполнены!");
            }

        }

        private void Sign1_Click(object sender, EventArgs e)
        {
            Login.Visible = false;
            Parol.Visible = false;
            Sign1.Visible = false;
            label8.Visible = false;
            pictureBox1.Visible = false;
            label9.Visible = false;
            Service_CB.Visible = false;
            Login.Text += Service_CB.Text;
            POMENYAT(true);
            
        }

       
    }
}
