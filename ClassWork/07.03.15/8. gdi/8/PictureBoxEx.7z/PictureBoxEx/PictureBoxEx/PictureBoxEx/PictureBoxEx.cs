﻿//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  License: GNU General Public License version 3 (GPLv3)
//
//  Email: pavel_torgashov@mail.ru.
//
//  Copyright (C) Pavel Torgashov, 2011. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Threading;
using System.Threading.Tasks;

namespace PictureBoxExNS
{
    public partial class PictureBoxEx : UserControl
    {
        const int x2 = 2;
        const int funcBufferSize = 1000;

        Bitmap visibleImage;
        Bitmap sourceImage2X;
        Point visibleCenter;
        public bool needRecalc;
        float rotate = 0f;
        float zoom = 1f;
        MouseState mouseState;
        Point startDragged;
        float startRotate;
        Point startDraggedVisibleCenter;
        Func<float, float, PointF> function;
        PointF[][] funcBuffer;
        Effects effect;
        int sourceImageWidth;
        int sourceImageHeight;

        public event EventHandler VisibleCenterChanged;
        public event EventHandler RotateAngleChanged;

        public bool JoinLeftRight { get; set; }
        public bool JoinTopBottom { get; set; }

        [DefaultValue(0.1f)]
        public float ZoomDelta { get; set; }
        [DefaultValue(0.2f)]
        public float RotateDelta { get; set; }
        [DefaultValue(true)]
        public bool AllowUserDrag { get; set; }
        [DefaultValue(true)]
        public bool AllowUserRotate { get; set; }
        [DefaultValue(true)]
        public bool AllowUserZoom { get; set; }

        public PictureBoxEx()
        {
            //drawing optimization
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.ResizeRedraw, true);
            //default settings
            ZoomDelta = 0.1f;
            RotateDelta = 0.2f;
            AllowUserDrag = true;
            AllowUserZoom = true;
            AllowUserRotate = true;
        }

        public Effects Effect
        {
            get { return effect; }
            set
            {
                effect = value;
                BuildEffect();
            }
        }

        private void BuildEffect()
        {
            switch (effect)
            {
                case Effects.Panorama:
                    Function = (x, y) => new PointF(x / (2 + (float)Math.Atan(x * x + y * y)), y / (2 + (float)Math.Atan(x * x + y * y)));
                    break;
                case Effects.InclinedPlane:
                    Function = (x, y) => new PointF(x / 2 * (2 - y), y);
                    break;
                case Effects.Sphere:
                    Function = (x, y) => new PointF(x * (1 + (float)Math.Atan(x * x + y * y)), y * (1 + (float)Math.Atan(x * x + y * y)));
                    break;
                case Effects.Lens1:
                    Function = (x, y) => (x * x + y * y) < 0.2f ? new PointF(x * (1 + (float)Math.Atan(x * x + y * y)), y * (1 + (float)Math.Atan(x * x + y * y))) : new PointF(x, y);
                    break;
                case Effects.Lens2:
                    Function = (x, y) => (x * x + y * y) > 0.2f ? new PointF(x * (1 + (float)Math.Atan(x * x + y * y)), y * (1 + (float)Math.Atan(x * x + y * y))) : new PointF(x * 0.5f, y * 0.5f);
                    break;
                case Effects.Drops:
                    BuildDropsFunction();
                    break;
                case Effects.Water:
                    Function = (x, y) => new PointF(x + (float)Math.Sin((x * x + y * y) * 50) / 100, y + (float)Math.Sin((x * x + y * y) * 50) / 100);
                    break;
                case Effects.FrostedGlass:
                    BuildFrostedGlassFunction();
                    break;
                case Effects.WaterMirror:
                    Function = (x, y) =>
                        y < 0.3?new PointF(x, y):
                                new PointF(x + (float)Math.Sin((x * x + y * y) * 50) / 100, 0.6f - y + (float)Math.Sin((x * x + y * y) * 50) / 100);
                    break;
                case Effects.None:
                    Function = (x, y) => new PointF(x, y);
                    break;
            }
            needRecalc = true;
            Invalidate();
        }

        [Browsable(false)]
        public Func<float, float, PointF> Function
        {
            get
            {
                return function;
            }
            set
            {
                function = value;
                BuildFuncBuffer();
            }
        }

        [DefaultValue(null)]
        public Image Image
        {
            get {
                if (sourceImage2X == null)
                    return null; 
                else
                    return new Bitmap(1, 1); 
            } 
            set {
                if (value == null)
                {
                    sourceImage2X = null;
                    visibleImage = null;
                    return;
                }
                sourceImageWidth = value.Width;
                sourceImageHeight = value.Height;

                needRecalc = true;
                visibleCenter = new Point(sourceImageWidth / 2, sourceImageHeight / 2);
                CreateImage2X(value);

                OnVisibleCenterChanged();
                Invalidate();
            }
        }

        [DefaultValue(0f)]
        public float RotateAngle
        {
            get
            {
                return rotate;
            }

            set
            {
                rotate = value;
                OnRotateAngleChanged();
            }
        }

        [DefaultValue(1f)]
        public float Zoom
        {
            get
            {
                return zoom;
            }

            set
            {
                if (Math.Abs(value) <= float.Epsilon)
                    throw new Exception("Zoom must be more then 0");
                zoom = value;
                needRecalc = true;
                Invalidate();
            }
        }

        public Point VisibleCenter
        {
            get
            {
                return visibleCenter;
            }

            set
            {
                visibleCenter = value;
                OnVisibleCenterChanged();
            }
        }

        public virtual void OnVisibleCenterChanged()
        {
            if (JoinLeftRight)
            {
                while (visibleCenter.X < 0) visibleCenter.X += sourceImageWidth;
                if (visibleCenter.X >= sourceImageWidth) visibleCenter.X %= sourceImageWidth;
            }
            if (JoinTopBottom)
            {
                while (visibleCenter.Y < 0) visibleCenter.Y += sourceImageHeight;
                if (visibleCenter.Y >= sourceImageHeight) visibleCenter.Y %= sourceImageHeight;
            }

            if(VisibleCenterChanged != null)
                VisibleCenterChanged(this, EventArgs.Empty);

            needRecalc = true;
            Invalidate();
        }

        public virtual void OnRotateAngleChanged()
        {
            if (RotateAngleChanged != null)
                RotateAngleChanged(this, EventArgs.Empty);

            Invalidate();
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);

            if (!AllowUserZoom)
                return;

            if (e.Delta > 0)
                IncreazeZoom();

            if (e.Delta < 0)
                DecreaseZoom();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (AllowUserDrag)
                if (e.Button == System.Windows.Forms.MouseButtons.Left)
                {
                    Cursor = Cursors.SizeAll;
                    mouseState = MouseState.Drag;
                }

            if (AllowUserRotate)
                if (e.Button == System.Windows.Forms.MouseButtons.Right)
                {
                    Cursor = Cursors.SizeNS;
                    mouseState = MouseState.Rotate;
                }

            startDragged = e.Location;
            startRotate = RotateAngle;
            startDraggedVisibleCenter = VisibleCenter;
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            Cursor = Cursors.Default;
            mouseState = MouseState.None;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (mouseState == MouseState.Drag)
            {
                Point d = new Point(e.Location.X - startDragged.X, e.Location.Y - startDragged.Y);
                double a = -Math.PI * rotate / 180;
                double dx = d.X * Math.Cos(a) - d.Y * Math.Sin(a);
                double dy = d.X * Math.Sin(a) + d.Y * Math.Cos(a);
                VisibleCenter = new Point((int)(startDraggedVisibleCenter.X - dx * x2 / zoom), (int)(startDraggedVisibleCenter.Y - dy * x2 /zoom));
            }

            if (mouseState == MouseState.Rotate)
            {
                Point d = new Point(e.Location.X - startDragged.X, e.Location.Y - startDragged.Y);
                RotateAngle = startRotate + d.Y * RotateDelta;
            }
        }

        public void DecreaseZoom()
        {
            Zoom = (float)Math.Exp(Math.Log(zoom) - ZoomDelta);
        }

        public void IncreazeZoom()
        {
            Zoom = (float)Math.Exp(Math.Log(zoom) + ZoomDelta);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (needRecalc)
                Recalc();
            if (visibleImage == null)
                return;
            e.Graphics.ResetTransform();
            e.Graphics.TranslateTransform(ClientSize.Width/2f, ClientSize.Height/2f);
            e.Graphics.RotateTransform(rotate);
            e.Graphics.DrawImageUnscaled(visibleImage, -visibleImage.Width / 2, -visibleImage.Height / 2);
        }

        protected override void OnClientSizeChanged(EventArgs e)
        {
            CreateVisibleImage();
        }

        private void CreateVisibleImage()
        {
            int w = (int)Math.Round(ClientSize.Width * Math.Sqrt(2));
            int h = (int)Math.Round(ClientSize.Height * Math.Sqrt(2));
            int s = Math.Max(h, w);
            if (s == 0)
                return;
            visibleImage = new Bitmap(s, s, PixelFormat.Format32bppArgb);
            needRecalc = true;
            Invalidate();
        }


        private void CreateImage2X(Image sourceImage)
        {
            if (sourceImage2X != null)
                sourceImage2X.Dispose();
            //создаем увеличинное исходное изображение
            sourceImage2X = new Bitmap(sourceImage.Width * x2, sourceImage.Height * x2, PixelFormat.Format32bppArgb);
            using (Graphics sourceGr2X = Graphics.FromImage(sourceImage2X))
            {
                sourceGr2X.InterpolationMode = InterpolationMode.HighQualityBicubic;
                sourceGr2X.DrawImage(sourceImage, 0, 0, sourceImage2X.Width + 1, sourceImage2X.Height + 1);
            }
        }

        public virtual void BuildFuncBuffer()
        {
            if (function == null)
                return;
            var w = funcBufferSize;
            var h = funcBufferSize;

            funcBuffer = new PointF[h][];

            Parallel.For(0, h, new ParallelOptions(), (y) =>
            //for (int y = 0; y < h; y++)
            {
                funcBuffer[y] = new PointF[w];
                for (int x = 0; x < w; x++)
                    funcBuffer[y][x] = function(2f * x / w - 1f, 2f * y / h - 1f);
            }
            );
        }

        public virtual void Recalc()
        {
            if (!needRecalc)
                return;
            needRecalc = false;
            //
            BuildVisibleImage();
        }


        unsafe void BuildVisibleImage()
        {
            if (funcBuffer == null || visibleImage==null || sourceImage2X == null)
                return;
            BitmapData BMPD1 = visibleImage.LockBits(new Rectangle(0, 0, visibleImage.Width, visibleImage.Height), ImageLockMode.WriteOnly, visibleImage.PixelFormat);
            BitmapData BMPD2 = sourceImage2X.LockBits(new Rectangle(0, 0, sourceImage2X.Width, sourceImage2X.Height), ImageLockMode.ReadOnly, sourceImage2X.PixelFormat);

            try
            {
                int stride1 = BMPD1.Stride;
                int* scan1 = (int*)(void*)BMPD1.Scan0;
                int stride2 = BMPD2.Stride;
                int* scan2 = (int*)(void*)BMPD2.Scan0;
                int h = visibleImage.Height;
                int w = visibleImage.Width;
                int dx = visibleCenter.X * 2 - (int)w / 2;
                int dy = visibleCenter.Y * 2 - (int)h / 2;
                int h2x = sourceImage2X.Height;
                int w2x = sourceImage2X.Width;
                int backColor = BackColor.ToArgb();
                var zoom = Zoom / x2;

                Parallel.For(0, h, new ParallelOptions(), (y) =>
                //for (int y = 0; y < h; y++)
                {
                    int* p1;
                    int* p2;

                    var buff = funcBuffer[funcBufferSize * y / h];

                    for (int x = 0; x < w; x++)
                    {
                        //get target pixel pointer
                        p1 = scan1 + stride1 * y / 4 + x;
                        //get transformed coordinates
                        PointF pF = buff[funcBufferSize * x / w];
                        int X = (int)Math.Round((pF.X / zoom + 1f) * w) + dx;
                        int Y = (int)Math.Round((pF.Y / zoom + 1f) * h) + dy;

                        if (JoinLeftRight)
                        {
                            while (X < 0) X += w2x;
                            if (X >= w2x) X %= w2x;
                        }
                        else
                        {
                            if (X < 0 || X >= w2x)
                            {
                                *p1 = backColor;
                                continue;
                            }
                        }
                        if (JoinTopBottom)
                        {
                            while (Y < 0) Y += h2x;
                            if (Y >= h2x) Y %= h2x;
                        }
                        else
                        {
                            if (Y < 0 || Y >= h2x)
                            {
                                *p1 = backColor;
                                continue;
                            }
                        }
                        //get source pixel pointer
                        p2 = scan2 + stride2 * Y / 4 + X;
                        //copy source pixel to target position
                        *p1 = *p2;
                    }
                }
                );
            }
            finally
            {
                visibleImage.UnlockBits(BMPD1);
                sourceImage2X.UnlockBits(BMPD2);
            }
        }

        public Image GetScreenshot()
        {
            Image img  = new Bitmap(ClientSize.Width, ClientSize.Height);
            OnPaint(new PaintEventArgs(Graphics.FromImage(img), ClientRectangle));
            return img;
        }
        
        private void BuildDropsFunction()
        {
            List<PointF> drops = new List<PointF>();
            for (int i = 0; i < 100; i++)
                drops.Add(new PointF((float)rnd.NextDouble() * 2 - 1, (float)rnd.NextDouble() * 2 - 1));
            Function = (x, y) =>
            {
                foreach (var drop in drops)
                {
                    var dx = x - drop.X;
                    var dy = y - drop.Y;
                    var r = dx * dx + dy * dy;
                    if (r < 0.001f)
                    {
                        dx = dx * 20;
                        dy = dy * 20;
                        return new PointF(-(float)Math.Atan(dx) + drop.X, -(float)Math.Atan(dy) + drop.Y);
                    }
                }
                return new PointF(x, y);
            };
        }

        static Random rnd = new Random();

        private void BuildFrostedGlassFunction()
        {    
            Function = (x, y) =>
            {
                if (x > -0.3 && x < 0.3 && y > -0.3 && y < 0.3)
                    return new PointF(x, y);
                lock(rnd)
                return new PointF(x + (float)(rnd.NextDouble() - 0.5) / 10, y + (float)(rnd.NextDouble() - 0.5) / 10);
            };
        }

        enum MouseState
        {
            None, Drag, Rotate
        }

        public enum Effects
        {
            None, Custom, Panorama, InclinedPlane, Sphere, Lens1, Lens2, Drops, Water, FrostedGlass, WaterMirror
        }
    }
}
