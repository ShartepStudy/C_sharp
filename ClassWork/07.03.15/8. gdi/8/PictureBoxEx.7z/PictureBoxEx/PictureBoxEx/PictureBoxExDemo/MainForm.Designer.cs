﻿using PictureBoxExNS;

namespace PictureBoxExDemoNS
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.button1 = new System.Windows.Forms.Button();
            this.ofdImage = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.cbJoinLeftRight = new System.Windows.Forms.CheckBox();
            this.cbTopBottom = new System.Windows.Forms.CheckBox();
            this.cbEffect = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBoxEx1 = new PictureBoxExNS.PictureBoxEx();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(51, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // ofdImage
            // 
            this.ofdImage.Filter = "Image|*.jpg;*.jpeg;*.png;*.bmp";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Image";
            // 
            // cbJoinLeftRight
            // 
            this.cbJoinLeftRight.AutoSize = true;
            this.cbJoinLeftRight.Location = new System.Drawing.Point(100, 5);
            this.cbJoinLeftRight.Name = "cbJoinLeftRight";
            this.cbJoinLeftRight.Size = new System.Drawing.Size(88, 17);
            this.cbJoinLeftRight.TabIndex = 3;
            this.cbJoinLeftRight.Text = "JoinLeftRight";
            this.cbJoinLeftRight.UseVisualStyleBackColor = true;
            this.cbJoinLeftRight.CheckedChanged += new System.EventHandler(this.cbJoinLeftRight_CheckedChanged);
            // 
            // cbTopBottom
            // 
            this.cbTopBottom.AutoSize = true;
            this.cbTopBottom.Location = new System.Drawing.Point(194, 5);
            this.cbTopBottom.Name = "cbTopBottom";
            this.cbTopBottom.Size = new System.Drawing.Size(97, 17);
            this.cbTopBottom.TabIndex = 4;
            this.cbTopBottom.Text = "JoinTopBottom";
            this.cbTopBottom.UseVisualStyleBackColor = true;
            this.cbTopBottom.CheckedChanged += new System.EventHandler(this.cbJoinLeftRight_CheckedChanged);
            // 
            // cbEffect
            // 
            this.cbEffect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEffect.FormattingEnabled = true;
            this.cbEffect.Location = new System.Drawing.Point(51, 27);
            this.cbEffect.Name = "cbEffect";
            this.cbEffect.Size = new System.Drawing.Size(121, 21);
            this.cbEffect.TabIndex = 5;
            this.cbEffect.SelectedValueChanged += new System.EventHandler(this.cbJoinLeftRight_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Effect";
            // 
            // pictureBoxEx1
            // 
            this.pictureBoxEx1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxEx1.Effect = PictureBoxExNS.PictureBoxEx.Effects.Sphere;
            this.pictureBoxEx1.Function = ((System.Func<float, float, System.Drawing.PointF>)(resources.GetObject("pictureBoxEx1.Function")));
            this.pictureBoxEx1.JoinLeftRight = false;
            this.pictureBoxEx1.JoinTopBottom = false;
            this.pictureBoxEx1.Location = new System.Drawing.Point(15, 54);
            this.pictureBoxEx1.Name = "pictureBoxEx1";
            this.pictureBoxEx1.Size = new System.Drawing.Size(339, 248);
            this.pictureBoxEx1.TabIndex = 0;
            this.pictureBoxEx1.VisibleCenter = new System.Drawing.Point(281, 80);
            // 
            // MainForm
            // 
            this.ClientSize = new System.Drawing.Size(366, 314);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbEffect);
            this.Controls.Add(this.cbTopBottom);
            this.Controls.Add(this.cbJoinLeftRight);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBoxEx1);
            this.Name = "MainForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBoxEx pictureBoxEx1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog ofdImage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbJoinLeftRight;
        private System.Windows.Forms.CheckBox cbTopBottom;
        private System.Windows.Forms.ComboBox cbEffect;
        private System.Windows.Forms.Label label2;
    }
}

