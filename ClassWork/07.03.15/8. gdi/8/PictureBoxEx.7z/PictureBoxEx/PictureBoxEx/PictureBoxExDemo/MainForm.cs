﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PictureBoxExNS;

namespace PictureBoxExDemoNS
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            foreach (string s in Enum.GetNames(typeof(PictureBoxEx.Effects)))
                cbEffect.Items.Add(s);
            cbEffect.Text = PictureBoxEx.Effects.Panorama.ToString();

            pictureBoxEx1.Image = Image.FromFile(AppDomain.CurrentDomain.BaseDirectory + "\\lake.jpg");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (ofdImage.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                pictureBoxEx1.Image = Image.FromFile(ofdImage.FileName);
        }

        private void cbJoinLeftRight_CheckedChanged(object sender, EventArgs e)
        {
            pictureBoxEx1.JoinLeftRight = cbJoinLeftRight.Checked;
            pictureBoxEx1.JoinTopBottom = cbTopBottom.Checked;
            pictureBoxEx1.Effect = (PictureBoxEx.Effects)Enum.Parse(typeof(PictureBoxEx.Effects), cbEffect.Text);
        }
    }
}
